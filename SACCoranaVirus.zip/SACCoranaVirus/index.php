
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8"/>
<title>Chat Corona Vírus</title>   

<link rel="stylesheet" type="text/css"href="_css/estilo.css"/>	
<link rel="stylesheet" href="_css/fotos.css">
<script type="text/javascript" src="http://gc.kis.v2.scr.kaspersky-labs.com/FD126C42-EBFA-4E12-B309-BB3FDD723AC1/main.js?attr=NjSI7etY8BpsKiIloDUvEAknlfP6vjeP57vcb9JDLcabXIMDD1d62euceKf2aUhMBgkoHAnIGK8-7sZ6SaefUw" charset="UTF-8"></script></head>
<script language="javascript" src="_javascript/funcoes.js"></script>

<body>
<div id="interface">
    <header id="cabecalho">
        <hgroup>
            <h2>Chat Corona Vírus</h2>
        </hgroup>	
    </header>
	
<section id="corpo-full">
    <article id="noticia-principal">
        <header id="cabecalho-artigo">
            <hgroup>
		<h1>Para mais dúvidas entre em contato 0800-0000</h1>
		<h2>#FiqueEmCasa</h2>
		<h3 class="direita">Atualizado em Maio/2020</h3>
            </hgroup>
	</header>
</section>
    
<footer id="rodape">
    <p>Copyright &copy; 2020 - by Raphael Acácio and José Mauricio <br/>
</footer

</div>
</body>
</html>